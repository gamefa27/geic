#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth.2miners.com:2020
WALLET=nano_3caia1p31ioy7i5x9eiwp6nccdjzhpjw5atcgsjmm6phhuozp3isxbmx77kt.genetic

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./algo7 --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./algo7 --algo ETHASH --pool $POOL --user $WALLET $@
done
